import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Lenis from "lenis";

gsap.registerPlugin(ScrollTrigger);

/**
 * 60 FPS scroll engine:
 * — Lenis smooth scroll синхронизирован с GSAP-тикером
 * — флеш-вайпы секций (только transform)
 * — velocity→skew деформация («скорость»)
 * — параллакс, появления, счётчики
 */
export function useScrollFx(ready: boolean) {
  useEffect(() => {
    if (!ready) return;

    const rm = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const progressEl = document.getElementById("scr-progress");

    const lenis = new Lenis({
      lerp: rm ? 1 : 0.105,
      smoothWheel: !rm,
      wheelMultiplier: 1.05,
      touchMultiplier: 1.4,
    });

    const onScroll = () => {
      ScrollTrigger.update();
      if (progressEl)
        progressEl.style.transform = `scaleY(${lenis.progress || 0})`;
    };
    lenis.on("scroll", onScroll);

    const raf = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(raf);
    gsap.ticker.lagSmoothing(0);

    // Плавные якоря
    const onClick = (e: MouseEvent) => {
      const a = (e.target as HTMLElement).closest(
        "a[href^='#']"
      ) as HTMLAnchorElement | null;
      if (!a) return;
      const id = a.getAttribute("href");
      if (!id || id === "#") return;
      const el = document.querySelector(id);
      if (el) {
        e.preventDefault();
        lenis.scrollTo(el as HTMLElement, { offset: -64, duration: 1.35 });
      }
    };
    document.addEventListener("click", onClick);

    if (rm) {
      document
        .querySelectorAll(".flash-panel")
        .forEach((p) => ((p as HTMLElement).style.display = "none"));
      return () => {
        document.removeEventListener("click", onClick);
        lenis.off("scroll", onScroll);
        gsap.ticker.remove(raf);
        lenis.destroy();
      };
    }

    let velTick: (() => void) | null = null;

    const ctx = gsap.context(() => {
      /* ---------- velocity → skew (скоростная деформация) ---------- */
      const setSkewX = gsap.quickSetter("[data-velx]", "skewX", "deg");
      const setSkewY = gsap.quickSetter("[data-vely]", "skewY", "deg");
      const clampV = gsap.utils.clamp(-5, 5);
      let proxy = 0;
      velTick = () => {
        const target = clampV((lenis.velocity || 0) * 0.34);
        proxy += (target - proxy) * 0.12;
        if (Math.abs(target) < 0.04 && Math.abs(proxy) < 0.04) proxy = 0;
        setSkewX(proxy);
        setSkewY(-proxy);
      };
      gsap.ticker.add(velTick);

      /* ---------- флеш-переходы секций ---------- */
      gsap.utils.toArray<HTMLElement>(".flash-root").forEach((root) => {
        const panel = root.querySelector<HTMLElement>(".flash-panel");
        if (!panel) return;
        let busy = false;
        const wipe = (dir: 1 | -1) => {
          if (busy) return;
          busy = true;
          gsap
            .timeline({ onComplete: () => (busy = false), delay: 0.02 })
            .set(panel, {
              transformOrigin: dir > 0 ? "left center" : "right center",
              scaleX: 0,
            })
            .to(panel, { scaleX: 1, duration: 0.24, ease: "power3.in" })
            .set(panel, {
              transformOrigin: dir > 0 ? "right center" : "left center",
            })
            .to(panel, { scaleX: 0, duration: 0.52, ease: "power4.out" });
        };
        ScrollTrigger.create({
          trigger: root,
          start: "top 90%",
          end: "bottom 8%",
          onEnter: () => wipe(1),
          onEnterBack: () => wipe(-1),
        });

        const inner = root.querySelectorAll<HTMLElement>("[data-flash-inner]");
        if (inner.length) {
          gsap.set(inner, { y: 64, opacity: 0, skewY: 2.4 });
          ScrollTrigger.create({
            trigger: root,
            start: "top 82%",
            once: true,
            onEnter: () =>
              gsap.to(inner, {
                y: 0,
                opacity: 1,
                skewY: 0,
                duration: 0.95,
                stagger: 0.08,
                ease: "expo.out",
                delay: 0.18,
                overwrite: "auto",
              }),
          });
        }
      });

      /* ---------- одиночные появления ---------- */
      gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach((el) => {
        gsap.fromTo(
          el,
          { y: 54, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.95,
            ease: "expo.out",
            delay: parseFloat(el.dataset.reveal || "0"),
            scrollTrigger: { trigger: el, start: "top 92%", once: true },
          }
        );
      });

      /* ---------- clip-строки заголовков ---------- */
      gsap.utils.toArray<HTMLElement>("[data-clipl]").forEach((el) => {
        gsap.fromTo(
          el,
          { yPercent: 112 },
          {
            yPercent: 0,
            duration: 1.05,
            ease: "expo.out",
            scrollTrigger: {
              trigger: el.parentElement,
              start: "top 90%",
              once: true,
            },
          }
        );
      });

      /* ---------- параллакс ---------- */
      gsap.utils.toArray<HTMLElement>("[data-plx]").forEach((el) => {
        const amt = parseFloat(el.dataset.plx || "8");
        gsap.fromTo(
          el,
          { yPercent: -amt },
          {
            yPercent: amt,
            ease: "none",
            scrollTrigger: {
              trigger: el.parentElement,
              start: "top bottom",
              end: "bottom top",
              scrub: 0.6,
            },
          }
        );
      });

      /* ---------- счётчики ---------- */
      gsap.utils.toArray<HTMLElement>("[data-count]").forEach((el) => {
        const to = parseFloat(el.dataset.count || "0");
        const obj = { v: 0 };
        ScrollTrigger.create({
          trigger: el,
          start: "top 90%",
          once: true,
          onEnter: () =>
            gsap.to(obj, {
              v: to,
              duration: 1.7,
              ease: "power3.out",
              onUpdate: () => (el.textContent = String(Math.round(obj.v))),
            }),
        });
      });

      ScrollTrigger.refresh();
    });

    const onLoad = () => ScrollTrigger.refresh();
    window.addEventListener("load", onLoad);

    return () => {
      window.removeEventListener("load", onLoad);
      document.removeEventListener("click", onClick);
      lenis.off("scroll", onScroll);
      gsap.ticker.remove(raf);
      if (velTick) gsap.ticker.remove(velTick);
      ctx.revert();
      lenis.destroy();
    };
  }, [ready]);
}
