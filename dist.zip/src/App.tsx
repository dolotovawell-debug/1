import { useCallback, useEffect, useState } from "react";
import { useScrollFx } from "./hooks/useScrollFx";
import { applyConsent, getConsent } from "./lib/consent";
import {
  Preloader,
  Cursor,
  SpeedRail,
  LegalNotice,
  PrivacyModal,
} from "./components/Overlay";
import { Nav } from "./components/Nav";
import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { Outdoor } from "./components/Outdoor";
import { SearchGeo } from "./components/Search";
import { Prices } from "./components/Prices";
import { Faq } from "./components/Faq";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  const [ready, setReady] = useState(false);
  const [policy, setPolicy] = useState(false);
  const onDone = useCallback(() => setReady(true), []);
  const openPolicy = useCallback(() => setPolicy(true), []);
  const closePolicy = useCallback(() => setPolicy(false), []);

  useScrollFx(ready);

  /* применяем сохранённый выбор cookie (метрика включается только при «Принять») */
  useEffect(() => {
    applyConsent(getConsent());
  }, []);

  /* пока прелоадер — скролл заблокирован */
  useEffect(() => {
    document.documentElement.style.overflow = ready ? "" : "hidden";
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [ready]);

  return (
    <div className="noise min-h-svh bg-[#07080b] text-[#f4f5f0] antialiased">
      <Preloader onDone={onDone} />
      <Cursor />
      <SpeedRail />
      <Nav />

      <main>
        <Hero ready={ready} />
        <Services />
        <Outdoor />
        <SearchGeo />
        <Prices />
        <Faq />
        <Contact />
      </main>

      <Footer onPolicy={openPolicy} />
      <LegalNotice onPolicy={openPolicy} />
      <PrivacyModal open={policy} onClose={closePolicy} />
    </div>
  );
}
