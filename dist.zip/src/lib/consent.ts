/* ------------------------------------------------------- */
/*  Управление согласием на cookie / аналитику (152-ФЗ)     */
/*  Яндекс.Метрика инициализируется ТОЛЬКО после выбора     */
/*  «Принять cookie». Выбор хранится в localStorage и       */
/*  может быть изменён/отозван в любое время.               */
/* ------------------------------------------------------- */

export type Consent = "all" | "essential" | null;

const KEY = "sp-consent-v3";

/* ↓ ЗАМЕНИТЕ НА НОМЕР ВАШЕГО СЧЁТЧИКА ЯНДЕКС.МЕТРИКИ ↓ */
const YM_ID = 105210999;

export const CONSENT_OPEN = "sp:consent:open";
export const CONSENT_CHANGE = "sp:consent:change";

export function getConsent(): Consent {
  try {
    const v = localStorage.getItem(KEY);
    return v === "all" || v === "essential" ? v : null;
  } catch {
    return null;
  }
}

/* ---- загрузка Метрики ---- */
let ymLoaded = false;

export function loadMetrika() {
  if (ymLoaded || typeof window === "undefined") return;
  ymLoaded = true;
  const w = window as any;
  /* канонический асинхронный загрузчик tag.js */
  w.ym =
    w.ym ||
    function () {
      (w.ym.a = w.ym.a || []).push(arguments);
    };
  w.ym.l = Date.now();
  const s = document.createElement("script");
  s.async = true;
  s.src = "https://mc.yandex.ru/metrika/tag.js";
  document.head.appendChild(s);
  w.ym(YM_ID, "init", {
    clickmap: true,
    trackLinks: true,
    accurateTrackBounce: false,
    webvisor: false,
  });
}

/* ---- отключение Метрики + очистка её cookie ---- */
export function disableMetrika() {
  if (typeof window === "undefined") return;
  const w = window as any;
  try {
    if (w.ym) w.ym(YM_ID, "destruct");
  } catch {
    /* noop */
  }
  const host = window.location.hostname.replace(/^www\./, "");
  const domains = ["", window.location.hostname, host, "." + host];
  const names = [
    "_ym_uid",
    "_ym_d",
    "_ym_isad",
    "_ym_visorc",
    "_ym_debug",
    "_ym_host",
    `_ym_mp2_subts_${YM_ID}`,
    `_ym_metrika_enabled_${YM_ID}`,
  ];
  const past = "=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
  names.forEach((n) =>
    domains.forEach((d) => {
      document.cookie = n + past + (d ? "; domain=" + d : "");
    })
  );
}

/* ---- применение выбора ---- */
export function applyConsent(c: Consent) {
  if (c === "all") loadMetrika();
  else disableMetrika();
}

export function setConsent(c: Exclude<Consent, null>) {
  try {
    localStorage.setItem(KEY, c);
  } catch {
    /* noop */
  }
  applyConsent(c);
  window.dispatchEvent(new CustomEvent(CONSENT_CHANGE, { detail: c }));
}

/** Открыть настройки cookie (используется из футера — отзыв/смена выбора) */
export function openConsentSettings() {
  window.dispatchEvent(new CustomEvent(CONSENT_OPEN));
}

export function consentLabel(c: Consent): string {
  if (c === "all") return "аналитика включена";
  if (c === "essential") return "аналитика отключена";
  return "выбор не сделан";
}
