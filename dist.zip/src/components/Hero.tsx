import { useEffect, useRef } from "react";
import gsap from "gsap";
import { Gauge, MapPin, MousePointer2 } from "lucide-react";
import { SITE, HERO_KWS } from "../lib/site";
import { TalkButtons, Marquee } from "./fx";

export function Hero({ ready }: { ready: boolean }) {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!ready || !root.current) return;
    const ctx = gsap.context(() => {
      gsap
        .timeline({ defaults: { ease: "expo.out" } })
        .to(".h-clip .clip-inner", {
          yPercent: 0,
          duration: 1.15,
          stagger: 0.09,
        })
        .fromTo(
          ".h-fade",
          { y: 34, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.9, stagger: 0.08 },
          "-=0.65"
        )
        .fromTo(
          ".h-strip",
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.7 },
          "-=0.4"
        );
    }, root);
    return () => ctx.revert();
  }, [ready]);

  return (
    <section ref={root} id="top" className="relative min-h-svh flex flex-col overflow-hidden">
      {/* фон: ночной шоссе-свет со скоростными линиями */}
      <div className="absolute inset-0" data-plx="6">
        <img
          src="/images/hero-speed.jpg"
          alt="Ночное шоссе Сочи — световые трассы скорости"
          className="w-full h-[118%] object-cover opacity-55"
          loading="eager"
          decoding="async"
          fetchPriority="high"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-[#07080b]/70 via-[#07080b]/35 to-[#07080b]" />
      <div className="absolute inset-0 plate opacity-60" />
      <div className="absolute inset-0 streaks opacity-70" />

      <div className="relative z-10 flex-1 flex flex-col justify-end px-4 md:px-8 pt-28 pb-6 max-w-[1600px] w-full mx-auto">
        {/* верхняя строка */}
        <div className="h-fade opacity-0 flex flex-wrap items-center gap-x-6 gap-y-2 mb-6 md:mb-10 text-[11px] tracking-[0.3em] uppercase text-[#c9ccd1]">
          <span className="aeo-head inline-flex items-center gap-2 text-[#cffe06]">
            <Gauge size={14} /> Цифровое агентство полного цикла
          </span>
          <span className="inline-flex items-center gap-2">
            <MapPin size={13} className="text-[#cffe06]" /> Сочи · Краснодарский край
          </span>
          <span className="hidden md:inline">mk · est · {SITE.domain}</span>
        </div>

        {/* заголовок */}
        <h1 data-vely className="font-bold uppercase leading-[0.88] tracking-[-0.035em] text-[clamp(3.2rem,11.5vw,11.5rem)]">
          <span className="h-clip clip-line">
            <span className="clip-inner" style={{ transform: "translateY(112%)" }}>
              Сайты<span className="text-[#cffe06]">.</span>
            </span>
          </span>
          <span className="h-clip clip-line">
            <span className="clip-inner" style={{ transform: "translateY(112%)" }}>
              Реклама<span className="text-[#cffe06]">.</span>
            </span>
          </span>
          <span className="h-clip clip-line">
            <span className="clip-inner t-stroke" style={{ transform: "translateY(112%)" }}>
              SEO·AEO·GEO
            </span>
          </span>
        </h1>

        {/* подстрочник + CTA */}
        <div className="mt-8 md:mt-10 grid lg:grid-cols-[1.2fr_1fr] gap-8 items-end">
          <div className="h-fade opacity-0">
            <p className="aeo-answer max-w-xl text-[15px] md:text-lg leading-relaxed text-[#c9ccd1]">
              <b className="text-white">СочиПРОФИ</b> — агентство в Сочи: сайты{" "}
              <b className="text-white">от 25 000 ₽ за 3–5 дней</b>, продвижение в поиске
              и в <b className="text-white">ответах нейросетей</b>, а также наружная
              реклама на собственном медиаэкране —{" "}
              <b className="text-[#cffe06]">ул. Транспортная, 74Б</b>.
            </p>
            <div className="mt-6">
              <TalkButtons />
            </div>
          </div>

          <div className="h-fade opacity-0 flex lg:justify-end items-center gap-5">
            <div className="relative hidden md:grid place-items-center w-28 h-28">
              <svg viewBox="0 0 100 100" className="absolute inset-0 spin-slow">
                <defs>
                  <path id="circ" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
                </defs>
                <text className="fill-[#9ba0a6] text-[8.2px] uppercase tracking-[0.22em]">
                  <textPath href="#circ">
                    листай вниз · скорость 60 fps · вайпы ·
                  </textPath>
                </text>
              </svg>
              <MousePointer2 size={18} className="text-[#cffe06]" />
            </div>
            <div className="text-right">
              <p className="text-5xl md:text-6xl font-bold tabular leading-none">
                <span data-count="350">0</span>
                <span className="text-[#cffe06]">+</span>
              </p>
              <p className="mt-1 text-[11px] tracking-[0.25em] uppercase text-[#9ba0a6]">
                проектов запущено
              </p>
            </div>
          </div>
        </div>

        {/* бегущая строка ядра */}
        <div className="h-strip opacity-0 mt-8 md:mt-12 -mx-4 md:-mx-8 border-y border-white/10 bg-[#07080b]/60 backdrop-blur-sm">
          <Marquee
            items={HERO_KWS}
            dur="26s"
            className="py-3.5 text-[13px] md:text-sm font-bold uppercase tracking-[0.18em]"
          />
        </div>
      </div>
    </section>
  );
}
