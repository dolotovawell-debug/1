import { Phone, Mail, MapPin, MessageCircle, Send, Hash, ShieldCheck, Building2, FileCheck } from "lucide-react";
import { SITE } from "../lib/site";
import { FlashSection, SectionHead } from "./fx";

const TILES = [
  {
    icon: Phone,
    label: "Телефон",
    value: SITE.phoneDisplay,
    href: SITE.phone,
    note: "звоните — отвечаем быстро",
    hot: true,
  },
  {
    icon: MessageCircle,
    label: "WhatsApp",
    value: SITE.phoneDisplay,
    href: SITE.wa,
    note: "чат и файлы",
  },
  {
    icon: Send,
    label: "Telegram",
    value: "@websochiprofi",
    href: SITE.tg,
    note: "личный канал связи",
  },
  {
    icon: Hash,
    label: "MAX",
    value: SITE.phoneDisplay,
    href: SITE.max,
    note: "национальный мессенджер",
  },
];

export function Contact() {
  return (
    <FlashSection id="contacts" flash="lime" className="py-20 md:py-28 px-4 md:px-8 plate">
      <div className="max-w-[1600px] mx-auto">
        <SectionHead
          tag="Прямой контакт"
          right="без форм · без спама · 152-фз ok"
          lines={[{ t: "Говорим" }, { t: "напрямую", cls: "t-stroke" }]}
        />

        <p data-flash-inner className="aeo-answer max-w-3xl text-[15px] md:text-xl leading-relaxed text-[#c9ccd1] -mt-6">
          На сайте <b className="text-white">нет форм заявок</b> — мы соблюдаем 152-ФЗ
          по-взрослому: вы сами выбираете канал и первым делаете шаг. Позвоните{" "}
          <a href={SITE.phone} className="u-link text-[#cffe06] font-bold">
            {SITE.phoneDisplay}
          </a>{" "}
          или напишите в мессенджер — смета и план в течение рабочего дня.
        </p>

        {/* Плитки */}
        <div className="mt-12 grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {TILES.map((t) => (
            <a
              key={t.label}
              href={t.href}
              target={t.href.startsWith("http") ? "_blank" : undefined}
              rel="noopener noreferrer"
              data-flash-inner
              className={`lift group relative p-6 md:p-7 min-h-[190px] flex flex-col justify-between border transition-colors duration-500 ${
                t.hot
                  ? "bg-[#cffe06] text-[#07080b] border-[#cffe06]"
                  : "bg-[#0d0f13] border-white/12 hover:border-[#cffe06]"
              }`}
            >
              <div className="flex items-center justify-between">
                <t.icon size={24} className={t.hot ? "text-[#07080b]" : "text-[#cffe06]"} />
                <span
                  className={`text-[10px] uppercase tracking-[0.2em] ${
                    t.hot ? "text-[#07080b]/60" : "text-[#9ba0a6]"
                  }`}
                >
                  {t.note}
                </span>
              </div>
              <div>
                <p
                  className={`text-[11px] uppercase tracking-[0.3em] mb-1 ${
                    t.hot ? "text-[#07080b]/60" : "text-[#9ba0a6]"
                  }`}
                >
                  {t.label}
                </p>
                <p className="text-xl md:text-2xl font-bold tracking-tight tabular">
                  {t.value}
                </p>
              </div>
            </a>
          ))}
        </div>

        {/* Почта + адрес + офис */}
        <div className="mt-4 grid md:grid-cols-3 gap-4">
          <a
            href={`mailto:${SITE.email}`}
            data-flash-inner
            className="lift border border-white/12 bg-[#0d0f13] p-6 flex items-center gap-4 hover:border-[#cffe06] transition-colors"
          >
            <Mail size={22} className="text-[#cffe06]" />
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-[#9ba0a6]">Email</p>
              <p className="font-bold text-[15px]">{SITE.email}</p>
            </div>
          </a>
          <div data-flash-inner className="border border-white/12 bg-[#0d0f13] p-6 flex items-center gap-4">
            <MapPin size={22} className="text-[#cffe06]" />
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-[#9ba0a6]">Офис и экран</p>
              <p className="font-bold text-[15px]">{SITE.address}</p>
            </div>
          </div>
          <div data-flash-inner className="border border-white/12 bg-[#0d0f13] p-6 flex items-center gap-4">
            <Building2 size={22} className="text-[#cffe06]" />
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-[#9ba0a6]">Встречи</p>
              <p className="font-bold text-[15px]">По записи · выезд по Сочи и краю</p>
            </div>
          </div>
        </div>

        {/* Юридическая строка */}
        <div data-flash-inner className="mt-4 flex flex-col md:flex-row gap-4">
          <div className="flex-1 flex items-start gap-3 border border-[#cffe06]/30 bg-[#cffe06]/5 p-6 text-[13px] leading-relaxed text-[#c9ccd1]">
            <ShieldCheck size={18} className="text-[#cffe06] shrink-0 mt-0.5" />
            <p>
              <b className="text-white">152-ФЗ соблюдён:</b> форм сбора персональных данных нет,
              обращения инициируете только вы. Для аналитики — обезличенная «Яндекс.Метрика»
              (cookie по политике Яндекса).
            </p>
          </div>
          <div className="flex-1 flex items-start gap-3 border border-white/12 bg-[#0d0f13] p-6 text-[13px] leading-relaxed text-[#9ba0a6]">
            <FileCheck size={18} className="text-[#cffe06] shrink-0 mt-0.5" />
            <p>
              Работаем по договору, предоставляем закрывающие документы. Реквизиты ИП/ООО — по
              запросу. Информация на сайте не является публичной офертой (ст. 437 ГК РФ).
            </p>
          </div>
        </div>
      </div>
    </FlashSection>
  );
}
