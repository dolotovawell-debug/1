import { useState } from "react";
import { Menu, X, Phone, Zap } from "lucide-react";
import { SITE } from "../lib/site";

const LINKS = [
  { href: "#services", t: "Услуги" },
  { href: "#screen", t: "Медиаэкран" },
  { href: "#geo", t: "SEO·AEO·GEO" },
  { href: "#prices", t: "Цены" },
  { href: "#faq", t: "Вопросы" },
  { href: "#contacts", t: "Контакты" },
];

export function Nav() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <header className="fixed top-0 inset-x-0 z-[160] mix-blend-normal">
        <div className="flex items-center justify-between px-4 md:px-8 py-4 bg-gradient-to-b from-[#07080b]/90 to-transparent">
          <a href="#top" className="flex items-center gap-2 group">
            <span className="w-8 h-8 grid place-items-center bg-[#cffe06] text-[#07080b]">
              <Zap size={16} strokeWidth={2.6} />
            </span>
            <span className="font-bold tracking-[-0.02em] text-lg leading-none">
              СОЧИ<span className="text-[#cffe06]">ПРОФИ</span>
            </span>
            <span className="hidden lg:inline text-[10px] tracking-[0.3em] text-[#9ba0a6] uppercase ml-2 group-hover:text-white transition-colors">
              {SITE.domain}
            </span>
          </a>

          <nav className="hidden lg:flex items-center gap-7">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="u-link text-[12px] font-bold uppercase tracking-[0.16em] text-[#c9ccd1] hover:text-white transition-colors"
              >
                {l.t}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href={SITE.phone}
              className="hidden md:inline-flex items-center gap-2 px-4 py-2.5 bg-[#cffe06] text-[#07080b] text-[12px] font-bold tracking-[0.1em] hover:bg-white transition-colors"
            >
              <Phone size={14} strokeWidth={2.6} />
              {SITE.phoneDisplay}
            </a>
            <button
              onClick={() => setOpen(!open)}
              className="lg:hidden w-10 h-10 grid place-items-center border border-white/20"
              aria-label="Меню"
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
      </header>

      {/* мобильное меню */}
      <div
        className={`fixed inset-0 z-[155] bg-[#07080b] transition-[clip-path] duration-500 ease-[cubic-bezier(0.77,0,0.18,1)] lg:hidden ${
          open ? "[clip-path:inset(0_0_0%_0)]" : "[clip-path:inset(0_0_100%_0)] pointer-events-none"
        }`}
      >
        <div className="h-full flex flex-col justify-center px-8 gap-2">
          {LINKS.map((l, i) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="flex items-baseline gap-4 py-2 border-b border-white/10"
            >
              <span className="text-[10px] text-[#cffe06] tabular">0{i + 1}</span>
              <span className="text-4xl font-bold uppercase tracking-[-0.02em]">{l.t}</span>
            </a>
          ))}
          <a
            href={SITE.phone}
            className="mt-8 inline-flex w-fit items-center gap-2 px-6 py-4 bg-[#cffe06] text-[#07080b] font-bold uppercase tracking-[0.12em] text-sm"
          >
            <Phone size={16} /> {SITE.phoneDisplay}
          </a>
        </div>
      </div>
    </>
  );
}
