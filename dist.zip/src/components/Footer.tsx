import { useEffect, useState } from "react";
import { Zap, ShieldCheck, Cookie, Settings2 } from "lucide-react";
import { SITE } from "../lib/site";
import {
  Consent,
  getConsent,
  consentLabel,
  openConsentSettings,
  CONSENT_CHANGE,
} from "../lib/consent";

export function Footer({ onPolicy }: { onPolicy: () => void }) {
  const [consent, setConsentState] = useState<Consent>(null);

  useEffect(() => {
    setConsentState(getConsent());
    const h = (e: Event) =>
      setConsentState((e as CustomEvent).detail as Consent);
    window.addEventListener(CONSENT_CHANGE, h);
    return () => window.removeEventListener(CONSENT_CHANGE, h);
  }, []);

  const dotCls =
    consent === "all"
      ? "bg-[#cffe06]"
      : consent === "essential"
        ? "bg-[#9ba0a6]"
        : "bg-[#ffb020] animate-pulse";

  return (
    <footer className="relative overflow-hidden border-t border-white/12 bg-[#07080b] px-4 md:px-8 pt-16 pb-8">
      <div className="max-w-[1600px] mx-auto">
        <div className="grid md:grid-cols-4 gap-10 md:gap-6 mb-16">
          <div className="md:col-span-2">
            <a href="#top" className="flex items-center gap-2 mb-5 w-fit">
              <span className="w-8 h-8 grid place-items-center bg-[#cffe06] text-[#07080b]">
                <Zap size={16} strokeWidth={2.6} />
              </span>
              <span className="font-bold text-lg">
                СОЧИ<span className="text-[#cffe06]">ПРОФИ</span>
              </span>
            </a>
            <p className="max-w-sm text-[13px] leading-relaxed text-[#9ba0a6]">
              Цифровое агентство в Сочи: сайты, реклама, SEO+AEO+GEO-продвижение и собственный
              медиаэкран. Работаем быстро, показываем цифры, отвечаем лично.
            </p>
          </div>

          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-[#9ba0a6] mb-4">Навигация</p>
            <nav className="flex flex-col gap-2.5 text-[14px]">
              {[
                ["Услуги", "#services"],
                ["Наружная реклама", "#screen"],
                ["SEO · AEO · GEO", "#geo"],
                ["Цены", "#prices"],
                ["Вопросы", "#faq"],
                ["Контакты", "#contacts"],
              ].map(([t, h]) => (
                <a key={h} href={h} className="u-link w-fit text-[#c9ccd1] hover:text-white transition-colors">
                  {t}
                </a>
              ))}
            </nav>
          </div>

          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-[#9ba0a6] mb-4">Контакты</p>
            <div className="flex flex-col gap-2.5 text-[14px]">
              <a href={SITE.phone} className="u-link w-fit text-[#cffe06] font-bold tabular">
                {SITE.phoneDisplay}
              </a>
              <a href={`mailto:${SITE.email}`} className="u-link w-fit text-[#c9ccd1]">
                {SITE.email}
              </a>
              <span className="text-[#c9ccd1]">{SITE.address}</span>
              <button
                onClick={onPolicy}
                className="u-link w-fit text-left inline-flex items-center gap-2 text-[#9ba0a6] hover:text-[#cffe06] transition-colors mt-2"
              >
                <ShieldCheck size={14} /> Политика конфиденциальности
              </button>
              <button
                onClick={openConsentSettings}
                className="group w-fit inline-flex items-center gap-2.5 mt-3 px-3.5 py-2.5 border border-white/20 hover:border-[#cffe06] transition-colors"
                aria-label="Открыть настройки cookie"
              >
                <Settings2 size={14} className="text-[#cffe06]" />
                <span className="text-[12px] font-bold uppercase tracking-[0.12em] text-[#c9ccd1] group-hover:text-white transition-colors">
                  Настройки cookie
                </span>
                <span className={`w-1.5 h-1.5 rounded-full ${dotCls}`} title={consentLabel(consent)} />
              </button>
              <p className="text-[10.5px] leading-snug text-[#9ba0a6] max-w-[240px]">
                <Cookie size={11} className="inline mr-1.5 -mt-0.5 text-[#cffe06]" />
                Яндекс.Метрика: <span className="text-[#c9ccd1]">{consentLabel(consent)}</span>.
                Выбор можно отозвать в любой момент.
              </p>
            </div>
          </div>
        </div>

        {/* водяное знак-имя */}
        <div aria-hidden className="select-none pointer-events-none overflow-hidden -mx-4 md:-mx-8">
          <p className="t-stroke whitespace-nowrap text-center font-bold uppercase tracking-[-0.04em] text-[13.5vw] leading-[0.95] opacity-25">
            СочиПрофи
          </p>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-[11px] tracking-[0.14em] uppercase text-[#9ba0a6]">
          <p>© 2026 СочиПРОФИ · {SITE.domain}</p>
          <p>
            152-ФЗ ok · метрика:{" "}
            <button onClick={openConsentSettings} className="u-link text-inherit hover:text-[#cffe06] transition-colors">
              {consentLabel(consent)}
            </button>
          </p>
          <p className="text-[#cffe06]">render: 060 fps · load: turbo</p>
        </div>
      </div>
    </footer>
  );
}
