import { useState } from "react";
import { Search as SearchIcon, MessageSquareQuote, Bot, TrendingUp, Link2, FileCode2, BrainCircuit, MapPin, Target } from "lucide-react";
import { CORE_SEO, CORE_AEO, CORE_GEO, CORE_CLUSTERS, GEO_MODS, BRAND_SHIELD, QTag } from "../lib/site";
import { FlashSection, SectionHead } from "./fx";

const PILLARS = [
  {
    icon: SearchIcon,
    code: "SEO",
    t: "Поисковые системы",
    d: "Классический топ: аудит, семантика, техника, контент, ссылки. Позиции в Яндексе и Google превращаются в заявки.",
    chips: CORE_SEO,
    accent: "text-[#cffe06]",
    ring: "hover:border-[#cffe06]",
  },
  {
    icon: MessageSquareQuote,
    code: "AEO",
    t: "Ответы поиска",
    d: "Answer Engine Optimization: прямые ответы, расширенные сниппеты, FAQ-разметка и голосовой поиск через Алису. Ваш ответ — нулевая позиция.",
    chips: CORE_AEO,
    accent: "text-[#36e2ff]",
    ring: "hover:border-[#36e2ff]",
  },
  {
    icon: Bot,
    code: "GEO",
    t: "Ответы нейросетей",
    d: "Generative Engine Optimization: ChatGPT, ЯндексGPT, Perplexity и Google AI Overviews рекомендуют ваш бренд. GEO не заменяет SEO — он его усиливает.",
    chips: CORE_GEO,
    accent: "text-[#ff3df2]",
    ring: "hover:border-[#ff3df2]",
  },
];

const STEPS = [
  { i: TrendingUp, t: "Семантика + кластеры", d: "Ядро запросов по Сочи и краю — на основе анализа конкурентов и частотности." },
  { i: FileCode2, t: "Разметка и техника", d: "Schema.org, speakable, Core Web Vitals ≥ 90, факты и цифры в формате «готовый ответ»." },
  { i: Link2, t: "Упоминания бренда", d: "Внешние площадки и геосервисы: 2ГИС, Яндекс.Карты, каталоги — сигналы доверия для ИИ." },
  { i: BrainCircuit, t: "Контроль нейровыдачи", d: "Мониторим, как ChatGPT, Нейро и Perplexity отвечают о вашей нише — и смещаем ответы к вам." },
];

const TIER: Record<QTag, string> = {
  ВЧ: "bg-[#cffe06] text-[#07080b]",
  СЧ: "border border-[#36e2ff]/70 text-[#36e2ff]",
  НЧ: "border border-white/25 text-[#9ba0a6]",
  VOICE: "border border-[#ff3df2]/70 text-[#ff3df2]",
};

const CHANNEL: Record<string, string> = {
  SEO: "bg-[#cffe06] text-[#07080b]",
  AEO: "bg-[#36e2ff] text-[#07080b]",
  GEO: "bg-[#ff3df2] text-[#07080b]",
  ADS: "bg-white text-[#07080b]",
  OOH: "bg-[#ffb020] text-[#07080b]",
};

const TOTAL_Q = CORE_CLUSTERS.reduce((n, c) => n + c.queries.length, 0);

export function SearchGeo() {
  const [clIdx, setClIdx] = useState(0);
  const cl = CORE_CLUSTERS[clIdx];

  return (
    <FlashSection id="geo" flash="cyan" className="py-20 md:py-28 px-4 md:px-8 bg-[#0a0c10]">
      <div className="max-w-[1600px] mx-auto">
        <SectionHead
          tag="Продвижение 2.0"
          right="ядро: 60+ кластеров под Сочи"
          lines={[
            { t: "Ищут. Отвечают." },
            { t: "Рекомендуют", cls: "t-stroke" },
          ]}
        />

        <p data-flash-inner className="aeo-answer max-w-3xl text-[15px] md:text-lg leading-relaxed text-[#c9ccd1] -mt-6 mb-12 md:mb-16">
          2026 год: клиент ищет не только в Яндексе — он спрашивает у нейросети. Поэтому мы
          ведём продвижение сразу по трём контурам — <b className="text-[#cffe06]">SEO</b>,{" "}
          <b className="text-[#36e2ff]">AEO</b> и <b className="text-[#ff3df2]">GEO</b>: сайт
          в топе, ответы в сниппетах, бренд — в рекомендациях ChatGPT и ЯндексGPT.
        </p>

        <div className="grid lg:grid-cols-[1.35fr_1fr] gap-4">
          {/* 3 колонки ядра */}
          <div className="grid md:grid-cols-3 gap-4">
            {PILLARS.map((p) => (
              <div
                key={p.code}
                data-flash-inner
                className={`lift border border-white/12 bg-[#07080b] p-6 flex flex-col ${p.ring} transition-colors`}
              >
                <div className="flex items-center justify-between mb-5">
                  <p.icon size={24} className={p.accent} />
                  <span className={`text-xl font-bold tracking-tight ${p.accent}`}>{p.code}</span>
                </div>
                <h3 className="text-lg font-bold uppercase mb-2">{p.t}</h3>
                <p className="text-[12.5px] leading-relaxed text-[#9ba0a6] mb-5">{p.d}</p>
                <div className="mt-auto flex flex-wrap gap-1.5">
                  {p.chips.map((c) => (
                    <span
                      key={c}
                      className="px-2 py-1 text-[10px] leading-none uppercase tracking-[0.08em] border border-white/12 text-[#c9ccd1] hover:bg-white hover:text-[#07080b] transition-colors cursor-default"
                    >
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* визуал нейроядра + шаги */}
          <div className="flex flex-col gap-4">
            <div data-flash-inner className="scanlines relative border border-white/12 overflow-hidden h-[220px] md:h-[260px]">
              <img
                src="/images/ai-core.jpg"
                alt="Нейросетевое ядро продвижения: ChatGPT, ЯндексGPT, Perplexity"
                className="kenburns w-full h-full object-cover"
                loading="lazy"
                decoding="async"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#07080b]/85 to-transparent" />
              <p className="absolute bottom-4 left-4 right-4 text-[11px] uppercase tracking-[0.25em] text-white/80">
                Ядро семантики → индекс нейросетей
              </p>
            </div>

            <div data-flash-inner className="border border-white/12 bg-[#07080b] p-6 grid sm:grid-cols-2 gap-5 flex-1">
              {STEPS.map((s) => (
                <div key={s.t}>
                  <s.i size={18} className="text-[#cffe06] mb-2.5" />
                  <p className="font-bold uppercase text-[13px] tracking-[0.05em] mb-1">{s.t}</p>
                  <p className="text-[12px] leading-relaxed text-[#9ba0a6]">{s.d}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ------- ПРОВОДНИК СЕМАНТИЧЕСКОГО ЯДРА ------- */}
        <div data-flash-inner className="mt-4 border border-white/12 bg-[#07080b]">
          <div className="flex flex-wrap items-center justify-between gap-3 px-5 md:px-7 py-5 border-b border-white/12">
            <p className="inline-flex items-center gap-2 text-[11px] md:text-xs tracking-[0.3em] uppercase text-[#9ba0a6]">
              <Target size={14} className="text-[#cffe06]" />
              Семантическое ядро · v2.0 по конкурентам
            </p>
            <div className="flex gap-5 text-[10.5px] uppercase tracking-[0.18em] text-[#9ba0a6] tabular">
              <span><b className="text-white">{TOTAL_Q}</b> фраз</span>
              <span><b className="text-white">7</b> кластеров</span>
              <span className="hidden md:inline"><b className="text-white">{GEO_MODS.length}</b> гео-модификаторов</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 px-5 md:px-7 py-4 border-b border-white/12">
            {CORE_CLUSTERS.map((c, i) => (
              <button
                key={c.id}
                onClick={() => setClIdx(i)}
                className={`inline-flex items-center gap-2.5 px-3.5 py-2 text-[11px] font-bold uppercase tracking-[0.12em] border transition-colors duration-300 ${
                  i === clIdx
                    ? "bg-[#cffe06] text-[#07080b] border-[#cffe06]"
                    : "border-white/15 text-[#c9ccd1] hover:border-[#cffe06] hover:text-[#cffe06]"
                }`}
              >
                {c.name}
                <span className={`tabular ${i === clIdx ? "text-[#07080b]/60" : "text-[#9ba0a6]"}`}>
                  {String(c.queries.length).padStart(2, "0")}
                </span>
              </button>
            ))}
          </div>

          <div key={cl.id} className="core-fade px-5 md:px-7 py-6">
            <div className="flex flex-wrap items-start gap-3 mb-5">
              <span className={`text-[9.5px] font-bold tracking-[0.2em] px-2 py-1 ${CHANNEL[cl.channel]}`}>
                {cl.channel}
              </span>
              <p className="text-[12.5px] leading-relaxed text-[#9ba0a6] max-w-3xl">{cl.role}</p>
            </div>
            <div className="flex flex-wrap gap-1.5 md:gap-2">
              {cl.queries.map((x) => (
                <span
                  key={x.q}
                  className="inline-flex items-center gap-2 px-3 py-1.5 border border-white/12 text-[11.5px] text-[#c9ccd1] hover:border-white/60 hover:text-white transition-colors cursor-default"
                >
                  {x.q}
                  <i className={`not-italic text-[8px] font-bold tracking-[0.14em] px-1.5 py-0.5 ${TIER[x.t]}`}>
                    {x.t}
                  </i>
                </span>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-[1.5fr_1fr] border-t border-white/12">
            <div className="px-5 md:px-7 py-4 border-b md:border-b-0 md:border-r border-white/12">
              <p className="inline-flex items-center gap-1.5 text-[9.5px] uppercase tracking-[0.25em] text-[#9ba0a6] mb-2.5">
                <MapPin size={11} className="text-[#cffe06]" /> Гео-модификаторы
              </p>
              <div className="flex flex-wrap gap-1.5">
                {GEO_MODS.map((g) => (
                  <span key={g} className="px-2.5 py-1 text-[10.5px] uppercase tracking-[0.08em] border border-white/12 text-[#c9ccd1]">
                    {g}
                  </span>
                ))}
              </div>
            </div>
            <div className="px-5 md:px-7 py-4">
              <p className="text-[9.5px] uppercase tracking-[0.25em] text-[#9ba0a6] mb-2.5">
                Бренд-защита
              </p>
              <div className="flex flex-wrap gap-1.5">
                {BRAND_SHIELD.map((b) => (
                  <span key={b} className="px-2.5 py-1 text-[10.5px] uppercase tracking-[0.08em] border border-[#cffe06]/40 text-[#cffe06]">
                    {b}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div data-flash-inner className="mt-6 grid grid-cols-2 md:grid-cols-4 border border-white/12">
          {[
            { v: "15000", suf: " ₽/мес", t: "старт SEO-комплекса" },
            { v: "2", suf: "–4 мес", t: "первый эффект" },
            { v: "5", suf: "+ нейросетей", t: "контролируем ответы" },
            { v: String(TOTAL_Q), suf: " фраз", t: "ядро v2.0 по Сочи" },
          ].map((m, i) => (
            <div key={i} className="p-5 md:p-6 border-white/12 [&:not(:last-child)]:border-r max-md:[&:nth-child(-n+2)]:border-b">
              <p className="text-2xl md:text-4xl font-bold tabular tracking-tight">
                {m.v}
                <span className="text-[#cffe06]">{m.suf}</span>
              </p>
              <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-[#9ba0a6]">{m.t}</p>
            </div>
          ))}
        </div>
      </div>
    </FlashSection>
  );
}
