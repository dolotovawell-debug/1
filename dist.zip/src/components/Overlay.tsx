import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { X, ShieldCheck, Phone, PhoneOff, ScrollText, BarChart3, Check, Minus } from "lucide-react";
import { SITE } from "../lib/site";
import {
  Consent,
  getConsent,
  setConsent,
  consentLabel,
  CONSENT_OPEN,
  CONSENT_CHANGE,
} from "../lib/consent";

/* ================= ПРЕЛОАДЕР ================= */
export function Preloader({ onDone }: { onDone: () => void }) {
  const root = useRef<HTMLDivElement>(null);
  const num = useRef<HTMLSpanElement>(null);
  const bar = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const obj = { v: 0 };
    const tl = gsap.timeline({
      onComplete: () => {
        gsap.set(root.current, { display: "none" });
        onDone();
      },
    });
    tl.to(obj, {
      v: 100,
      duration: 1.15,
      ease: "power2.inOut",
      onUpdate: () => {
        if (num.current)
          num.current.textContent = String(Math.round(obj.v)).padStart(3, "0");
        if (bar.current) bar.current.style.transform = `scaleX(${obj.v / 100})`;
      },
    })
      .to(root.current!.querySelector(".pre-flash"), {
        opacity: 1,
        duration: 0.07,
        repeat: 3,
        yoyo: true,
        ease: "none",
      })
      .to(root.current, {
        yPercent: -100,
        duration: 0.85,
        ease: "expo.inOut",
      });
    return () => {
      tl.kill();
    };
  }, [onDone]);

  return (
    <div
      ref={root}
      className="fixed inset-0 z-[200] bg-[#07080b] flex flex-col justify-between p-6 md:p-10 will-change-transform"
    >
      <div className="pre-flash absolute inset-0 bg-[#cffe06] opacity-0 pointer-events-none" />
      <div className="flex justify-between items-start">
        <p className="text-[11px] tracking-[0.4em] uppercase text-[#9ba0a6]">
          СочиПРОФИ // загрузка
        </p>
        <p className="text-[11px] tracking-[0.4em] uppercase text-[#9ba0a6] hidden md:block">
          60 fps mode
        </p>
      </div>
      <div className="relative z-10">
        <p className="text-[12vw] md:text-[8vw] leading-none font-bold tracking-[-0.04em] uppercase">
          Сайты<span className="text-[#cffe06]">.</span>Реклама
          <span className="text-[#cffe06]">.</span>SEO
        </p>
        <div className="mt-8 flex items-end gap-6">
          <span
            ref={num}
            className="tabular text-7xl md:text-8xl font-bold leading-none text-[#cffe06]"
          >
            000
          </span>
          <span className="text-[11px] tracking-[0.4em] uppercase text-[#9ba0a6] mb-2">
            процентов скорости
          </span>
        </div>
        <div className="mt-6 h-[3px] w-full bg-white/10">
          <div
            ref={bar}
            className="h-full w-full bg-[#cffe06] origin-left scale-x-0 will-change-transform"
          />
        </div>
      </div>
    </div>
  );
}

/* ================= КАСТОМНЫЙ КУРСОР ================= */
export function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    let x = innerWidth / 2, y = innerHeight / 2, rx = x, ry = y, raf = 0;
    let scale = 1;
    const move = (e: MouseEvent) => {
      x = e.clientX;
      y = e.clientY;
      const t = (e.target as HTMLElement).closest("a,button,[data-hover]");
      scale = t ? 2.6 : 1;
    };
    const loop = () => {
      rx += (x - rx) * 0.14;
      ry += (y - ry) * 0.14;
      if (dot.current)
        dot.current.style.transform = `translate3d(${x}px,${y}px,0) translate(-50%,-50%)`;
      if (ring.current)
        ring.current.style.transform = `translate3d(${rx}px,${ry}px,0) translate(-50%,-50%) scale(${scale})`;
      raf = requestAnimationFrame(loop);
    };
    window.addEventListener("mousemove", move, { passive: true });
    raf = requestAnimationFrame(loop);
    return () => {
      window.removeEventListener("mousemove", move);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div className="hidden md:block" aria-hidden>
      <div
        ref={dot}
        className="fixed top-0 left-0 z-[300] w-1.5 h-1.5 rounded-full bg-[#cffe06] pointer-events-none"
      />
      <div
        ref={ring}
        className="fixed top-0 left-0 z-[299] w-9 h-9 rounded-full border border-[#cffe06]/60 pointer-events-none mix-blend-difference transition-[border-color] duration-300"
      />
    </div>
  );
}

/* ================= РЕЙЛ ПРОГРЕССА + FPS ================= */
export function SpeedRail() {
  const fpsRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    let frames = 0, last = performance.now(), raf = 0;
    const loop = (t: number) => {
      frames++;
      if (t - last >= 600) {
        const fps = Math.round((frames * 1000) / (t - last));
        if (fpsRef.current)
          fpsRef.current.textContent = String(Math.min(fps, 240)).padStart(3, "0");
        frames = 0;
        last = t;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <>
      <div className="fixed right-3 md:right-5 top-1/2 -translate-y-1/2 z-[95] hidden sm:flex flex-col items-center gap-3">
        <span className="text-[9px] tracking-[0.3em] text-[#9ba0a6] [writing-mode:vertical-rl]">
          SCROLL
        </span>
        <div className="w-[3px] h-28 bg-white/10 overflow-hidden rounded-full">
          <div
            id="scr-progress"
            className="w-full h-full bg-[#cffe06] origin-top scale-y-0 will-change-transform"
          />
        </div>
        <span className="text-[9px] tracking-[0.3em] text-[#cffe06] [writing-mode:vertical-rl]">
          SPEED
        </span>
      </div>
      <div className="fixed left-3 md:left-5 bottom-3 z-[95] hidden md:flex items-center gap-2 text-[10px] tracking-[0.25em] text-[#9ba0a6]">
        <span className="w-1.5 h-1.5 rounded-full bg-[#cffe06] animate-pulse" />
        <span ref={fpsRef} className="tabular text-white">
          060
        </span>
        <span>FPS</span>
      </div>
    </>
  );
}

/* ========== СОГЛАСИЕ НА COOKIE + ИНФО-УВЕДОМЛЕНИЕ (152-ФЗ, ст. 437 ГК) ========== */
export function LegalNotice({ onPolicy }: { onPolicy: () => void }) {
  const [show, setShow] = useState(false);
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState<Consent>(null);

  /* первый показ — только если выбор ещё не сделан; повторно — из футера */
  useEffect(() => {
    setCurrent(getConsent());
    let t: number;
    if (!getConsent()) t = window.setTimeout(() => setShow(true), 2400);

    const onOpen = () => {
      setCurrent(getConsent());
      setShow(true);
    };
    const onChange = (e: Event) =>
      setCurrent((e as CustomEvent).detail as Consent);
    window.addEventListener(CONSENT_OPEN, onOpen);
    window.addEventListener(CONSENT_CHANGE, onChange);
    return () => {
      clearTimeout(t);
      window.removeEventListener(CONSENT_OPEN, onOpen);
      window.removeEventListener(CONSENT_CHANGE, onChange);
    };
  }, []);

  useEffect(() => {
    if (!show) return;
    const r = requestAnimationFrame(() =>
      requestAnimationFrame(() => setOpen(true))
    );
    return () => cancelAnimationFrame(r);
  }, [show]);

  const close = () => {
    setOpen(false);
    window.setTimeout(() => setShow(false), 700);
  };

  const choose = (c: Exclude<Consent, null>) => {
    setConsent(c);
    close();
  };

  if (!show) return null;

  return (
    <div
      role="note"
      aria-label="Информационное уведомление"
      className={`fixed z-[150] inset-x-0 bottom-0 will-change-transform transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] ${
        open ? "translate-y-0" : "translate-y-full"
      }`}
    >
      <div className="border-t-2 border-[#cffe06] bg-[#0b0d10]/95 backdrop-blur-md shadow-[0_-20px_60px_-20px_rgba(0,0,0,0.8)]">
        <div className="max-w-[1600px] mx-auto px-4 md:px-8 py-4 md:py-5">
          <div className="flex flex-col lg:flex-row lg:items-center gap-4 lg:gap-8">
            {/* заголовок */}
            <div className="flex items-center gap-3 shrink-0 lg:w-[260px]">
              <span className="w-10 h-10 grid place-items-center bg-[#cffe06] text-[#07080b] shrink-0">
                <ShieldCheck size={18} strokeWidth={2.4} />
              </span>
              <div>
                <p className="text-[12px] font-bold uppercase tracking-[0.16em] leading-tight">
                  Информационное уведомление
                </p>
                <p className="text-[9.5px] tracking-[0.22em] uppercase text-[#9ba0a6] mt-0.5">
                  ст. 437 ГК РФ · 152-ФЗ
                </p>
              </div>
            </div>

            {/* текст уведомления */}
            <div className="grid md:grid-cols-3 gap-x-7 gap-y-3.5 max-lg:max-h-[34svh] max-lg:overflow-y-auto max-lg:pr-2">
              <div className="flex gap-2.5 text-[11.5px] leading-[1.55] text-[#c9ccd1]">
                <ScrollText size={14} className="text-[#cffe06] shrink-0 mt-[3px]" />
                <p>
                  <b className="text-white">Не оферта.</b> Наш сайт носит исключительно
                  информационный характер и не является публичной офертой в соответствии
                  со ст. 437 Гражданского кодекса РФ. Цены, сроки и условия приведены
                  справочно и могут уточняться менеджером по телефону.
                </p>
              </div>
              <div className="flex gap-2.5 text-[11.5px] leading-[1.55] text-[#c9ccd1]">
                <PhoneOff size={14} className="text-[#cffe06] shrink-0 mt-[3px]" />
                <p>
                  <b className="text-white">Без сбора данных.</b> Сайт не содержит форм
                  сбора персональных данных — все обращения совершаются напрямую через
                  кнопки телефонного звонка и мессенджеров (MAX, WhatsApp, Telegram),
                  инициированные самим пользователем.
                </p>
              </div>
              <div className="flex gap-2.5 text-[11.5px] leading-[1.55] text-[#c9ccd1]">
                <BarChart3 size={14} className="text-[#cffe06] shrink-0 mt-[3px]" />
                <p>
                  <b className="text-white">Аналитика.</b> Для анализа посещаемости
                  используется сервис «Яндекс.Метрика» (Яндекс), который может
                  обрабатывать обезличенные данные и файлы cookie в соответствии с
                  Федеральным законом № 152-ФЗ «О персональных данных» и политикой
                  конфиденциальности Яндекса.
                </p>
              </div>
            </div>

            {/* действия — выбор пользователя */}
            <div className="flex flex-col gap-2.5 shrink-0 lg:w-[300px]">
              <div className="flex lg:flex-col gap-2.5">
                <button
                  onClick={() => choose("all")}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 bg-[#cffe06] text-[#07080b] text-[12px] font-bold uppercase tracking-[0.12em] hover:bg-white transition-colors"
                >
                  <Check size={15} strokeWidth={2.8} /> Принять cookie
                </button>
                <button
                  onClick={() => choose("essential")}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 border border-white/25 text-[12px] font-bold uppercase tracking-[0.12em] text-white/85 hover:border-[#cffe06] hover:text-[#cffe06] transition-colors"
                >
                  <Minus size={15} strokeWidth={2.8} /> Только необходимые
                </button>
              </div>
              <button
                onClick={onPolicy}
                className="u-link w-fit self-start lg:self-end text-[10.5px] uppercase tracking-[0.16em] text-[#9ba0a6] hover:text-[#cffe06] transition-colors py-0.5"
              >
                Политика конфиденциальности
              </button>
              <p className="text-[9.5px] leading-snug text-[#9ba0a6] lg:text-right">
                Сейчас:{" "}
                <span className={current === "all" ? "text-[#cffe06]" : "text-white/70"}>
                  {consentLabel(current)}
                </span>
                . Изменить или отозвать выбор можно в любое время — «Настройки cookie»
                внизу сайта.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= ПОЛИТИКА (152-ФЗ, информационная) ================= */
export function PrivacyModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) document.addEventListener("keydown", esc);
    return () => document.removeEventListener("keydown", esc);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[250] flex items-center justify-center p-4 md:p-8"
      role="dialog"
      aria-modal="true"
      aria-label="Политика конфиденциальности"
    >
      <div
        className="absolute inset-0 bg-[#07080b]/90 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-3xl max-h-[85vh] overflow-y-auto bg-[#0d0f13] border border-white/15 p-6 md:p-10">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 grid place-items-center border border-white/20 hover:border-[#cffe06] hover:text-[#cffe06] transition-colors"
          aria-label="Закрыть"
        >
          <X size={18} />
        </button>

        <p className="flex items-center gap-2 text-[11px] tracking-[0.3em] uppercase text-[#cffe06] mb-3">
          <ShieldCheck size={15} /> ФЗ № 152 «О персональных данных»
        </p>
        <h3 className="text-2xl md:text-4xl font-bold uppercase tracking-[-0.02em] mb-6">
          Политика конфиденциальности
        </h3>

        <div className="space-y-5 text-[14px] leading-relaxed text-[#c9ccd1]">
          <div>
            <p className="text-white font-bold mb-1">1. Сайт носит информационный характер</p>
            <p>
              Сайт <b className="text-white">{SITE.domain}</b> носит исключительно
              информационный характер и не является публичной офертой в соответствии со
              ст. 437 Гражданского кодекса РФ. Указанные цены, сроки и условия приведены
              справочно и могут уточняться менеджером по телефону. Сайт не содержит форм
              сбора персональных данных — все обращения совершаются напрямую через кнопки
              телефонного звонка и мессенджеров (MAX, WhatsApp, Telegram),
              инициированные самим пользователем. Данные, переданные в мессенджерах,
              обрабатываются по правилам соответствующих платформ.
            </p>
          </div>
          <div>
            <p className="text-white font-bold mb-1">2. Аналитика — «Яндекс.Метрика»</p>
            <p>
              Для анализа посещаемости используется сервис «Яндекс.Метрика» (Яндекс),
              который может обрабатывать обезличенные данные и файлы cookie в
              соответствии с Федеральным законом № 152-ФЗ «О персональных данных» и
              политикой конфиденциальности Яндекса. Вебвизор и запись сессий не
              используются.
            </p>
          </div>
          <div>
            <p className="text-white font-bold mb-1">3. Cookie и управление согласием</p>
            <p>
              Cookie применяются для обезличенной статистики и корректной работы сайта.
              Выбор «Принять cookie» / «Только необходимые» фиксируется при первом
              визите; изменить или <b className="text-white">отозвать согласие</b> можно в
              любой момент — кнопка «Настройки cookie» внизу каждой страницы. Также вы
              можете ограничить или отключить cookie в настройках браузера —
              функциональность сайта от этого не пострадает.
            </p>
          </div>
          <div>
            <p className="text-white font-bold mb-1">4. Ваши права</p>
            <p>
              Вы вправе запросить информацию об обработке данных, а также потребовать
              уточнения, блокирования или уничтожения данных, направив запрос на{" "}
              <a className="u-link text-[#cffe06]" href={`mailto:${SITE.email}`}>
                {SITE.email}
              </a>{" "}
              или по телефону{" "}
              <a className="u-link text-[#cffe06]" href={SITE.phone}>
                {SITE.phoneDisplay}
              </a>
              .
            </p>
          </div>
          <p className="text-[12px] text-[#9ba0a6] pt-2 border-t border-white/10">
            Оператор: «СочиПРОФИ», Россия, г. Сочи, ул. Транспортная, 74Б. Реквизиты
            ИП/ООО предоставляются по запросу. Настоящая редакция действует с 01.01.2026.
          </p>
        </div>

        <a
          href={SITE.phone}
          className="mt-8 inline-flex items-center gap-2 px-5 py-3 bg-[#cffe06] text-[#07080b] text-[12px] font-bold uppercase tracking-[0.14em] hover:bg-white transition-colors"
        >
          <Phone size={15} /> Задать вопрос по телефону
        </a>
      </div>
    </div>
  );
}
