import { Timer, ArrowUpRight } from "lucide-react";
import { PRICES, SERVICES } from "../lib/site";
import { FlashSection, SectionHead, TalkButtons } from "./fx";

export function Prices() {
  return (
    <FlashSection id="prices" flash="lime" className="py-20 md:py-28 px-4 md:px-8 plate">
      <div className="max-w-[1600px] mx-auto">
        <SectionHead
          tag="Прозрачная смета"
          right="фиксация в договоре"
          lines={[{ t: "Цены" }, { t: "без звёздочек", cls: "t-stroke" }]}
        />

        {/* карточки типов сайтов */}
        <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-4">
          {PRICES.map((p, i) => (
            <div
              key={p.t}
              data-flash-inner
              className="lift group relative border border-white/12 bg-[#0d0f13] p-6 md:p-7 flex flex-col min-h-[260px] hover:border-[#cffe06]"
            >
              <span className="absolute top-5 right-5 text-[11px] tabular text-[#9ba0a6]">
                0{i + 1}
              </span>
              <h3 className="text-xl md:text-2xl font-bold uppercase leading-tight mb-3 max-w-[80%]">
                {p.t}
              </h3>
              <p className="text-[13px] leading-relaxed text-[#9ba0a6]">{p.d}</p>
              <div className="mt-auto pt-6">
                <p className="text-3xl font-bold tabular tracking-tight group-hover:text-[#cffe06] transition-colors">
                  {p.p}
                </p>
                <p className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.2em] text-[#9ba0a6]">
                  <Timer size={12} className="text-[#cffe06]" /> {p.s}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* строки остальных услуг */}
        <div className="border-t border-white/12">
          {SERVICES.filter((s) => s.id !== "web").map((s) => (
            <a
              key={s.id}
              href={s.id === "screen" ? "#screen" : "#contacts"}
              data-flash-inner
              className="group flex items-center justify-between gap-4 md:gap-8 py-4 md:py-5 border-b border-white/12 hover:bg-white/[0.03] transition-colors px-1 md:px-3"
            >
              <span className="flex items-center gap-4 min-w-0">
                <span className="text-[11px] tabular text-[#9ba0a6]">/{s.n}</span>
                <span className="text-[15px] md:text-xl font-bold uppercase tracking-tight truncate group-hover:text-[#cffe06] transition-colors">
                  {s.title}
                </span>
              </span>
              <span className="flex items-center gap-4 md:gap-10 shrink-0">
                <span className="hidden md:inline text-[11px] uppercase tracking-[0.15em] text-[#9ba0a6]">
                  {s.term}
                </span>
                <span className="text-[14px] md:text-base font-bold tabular text-[#cffe06]">
                  {s.price}
                </span>
                <ArrowUpRight size={17} className="text-[#9ba0a6] group-hover:text-[#cffe06] group-hover:rotate-45 transition-all duration-300" />
              </span>
            </a>
          ))}
        </div>

        <div data-flash-inner className="mt-10 flex flex-col md:flex-row md:items-center justify-between gap-6 border border-white/12 bg-[#0d0f13] p-6 md:p-8">
          <p className="max-w-xl text-[14px] leading-relaxed text-[#c9ccd1]">
            Точную смету называем после <b className="text-white">15-минутного созвона</b> —
            и фиксируем её в договоре. Работаем с закрывающими документами, оплата по
            этапам.
          </p>
          <TalkButtons />
        </div>
      </div>
    </FlashSection>
  );
}
