import { Plus, MessagesSquare } from "lucide-react";
import { FAQ } from "../lib/site";
import { FlashSection, SectionHead } from "./fx";

export function Faq() {
  return (
    <FlashSection id="faq" flash="cyan" className="py-20 md:py-28 px-4 md:px-8 bg-[#0a0c10]">
      <div className="max-w-[1600px] mx-auto grid lg:grid-cols-[1fr_1.5fr] gap-10 lg:gap-16">
        <div>
          <SectionHead
            tag="AEO-контур"
            lines={[{ t: "Вопрос" }, { t: "— ответ", cls: "t-stroke" }]}
          />
          <div data-flash-inner className="flex items-start gap-3 max-w-sm text-[13px] leading-relaxed text-[#9ba0a6] -mt-4">
            <MessagesSquare size={18} className="text-[#36e2ff] shrink-0 mt-0.5" />
            <p>
              Эти ответы размечены Schema.org FAQPage: их напрямую подхватывают поисковая
              выдача, голосовые ассистенты и нейросети. Так работает AEO — ваш ответ звучит
              первым.
            </p>
          </div>
        </div>

        <div>
          {FAQ.map((f, i) => (
            <details
              key={i}
              data-flash-inner
              className="group border-b border-white/12 open:bg-white/[0.02] transition-colors"
            >
              <summary className="flex items-center justify-between gap-6 cursor-pointer list-none py-5 md:py-6 px-1 md:px-3 [&::-webkit-details-marker]:hidden">
                <span className="flex items-baseline gap-4">
                  <span className="text-[11px] tabular text-[#36e2ff]">Q{i + 1}</span>
                  <span className="text-[15px] md:text-xl font-bold uppercase tracking-tight group-open:text-[#cffe06] transition-colors">
                    {f.q}
                  </span>
                </span>
                <span className="shrink-0 w-9 h-9 grid place-items-center border border-white/20 group-open:rotate-45 group-open:border-[#cffe06] group-open:text-[#cffe06] transition-all duration-300">
                  <Plus size={16} />
                </span>
              </summary>
              <p className="aeo-answer px-1 md:px-3 pb-6 pl-[calc(0.25rem+2.5rem)] md:pl-[calc(0.75rem+2.5rem)] max-w-2xl text-[14px] leading-relaxed text-[#c9ccd1]">
                {f.a}
              </p>
            </details>
          ))}
        </div>
      </div>
    </FlashSection>
  );
}
