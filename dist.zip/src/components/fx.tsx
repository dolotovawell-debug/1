import { ReactNode } from "react";
import { Phone, Send, MessageCircle, Hash, ArrowUpRight } from "lucide-react";
import { SITE } from "../lib/site";

/* ---------------- Flash section с цветным вайпом ---------------- */
const PANEL: Record<string, string> = {
  lime: "bg-[#cffe06]",
  cyan: "bg-[#36e2ff]",
  mag: "bg-[#ff3df2]",
  white: "bg-[#f4f5f0]",
  ink: "bg-[#07080b]",
};

export function FlashSection({
  id,
  flash = "lime",
  className = "",
  children,
}: {
  id?: string;
  flash?: keyof typeof PANEL;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className={`flash-root relative overflow-hidden ${className}`}>
      {children}
      <div className={`flash-panel ${PANEL[flash as string] || PANEL.lime}`} aria-hidden />
    </section>
  );
}

/* ---------------- Заголовок секции ---------------- */
export function SectionHead({
  tag,
  lines,
  right,
}: {
  tag: string;
  lines: { t: string; cls?: string }[];
  right?: string;
}) {
  return (
    <div className="mb-12 md:mb-16" data-flash-inner>
      <div className="flex items-end justify-between gap-6 mb-5">
        <p className="text-[11px] md:text-xs tracking-[0.35em] uppercase text-[#9ba0a6]">
          <span className="text-[#cffe06]">●</span>&nbsp; {tag}
        </p>
        {right && (
          <p className="hidden md:block text-[11px] tracking-[0.3em] uppercase text-[#9ba0a6]">
            {right}
          </p>
        )}
      </div>
      <h2 className="font-bold uppercase leading-[0.92] tracking-[-0.03em] text-[clamp(2.6rem,7.5vw,7rem)]">
        {lines.map((l, i) => (
          <span key={i} className="clip-line">
            <span className="clip-inner inline-block" data-clipl>
              <span className={l.cls}>{l.t}</span>
            </span>
          </span>
        ))}
      </h2>
    </div>
  );
}

/* ---------------- Бегущая строка ---------------- */
export function Marquee({
  items,
  className = "",
  dur = "30s",
  itemCls = "",
  sepCls = "text-[#cffe06]",
}: {
  items: string[];
  className?: string;
  dur?: string;
  itemCls?: string;
  sepCls?: string;
}) {
  const row = (k: number) => (
    <span key={k} className="inline-flex items-center shrink-0">
      {items.map((it, i) => (
        <span key={i} className={`inline-flex items-center whitespace-nowrap ${itemCls}`}>
          <span className="mx-5 md:mx-7">{it}</span>
          <span className={sepCls}>×</span>
        </span>
      ))}
    </span>
  );
  return (
    <div className={`mq ${className}`} data-velx>
      <div className="mq-track" style={{ ["--mq-dur" as string]: dur }}>
        {row(0)}
        {row(1)}
      </div>
    </div>
  );
}

/* ---------------- Кликабельные кнопки общения (без форм) ---------------- */
export function TalkButtons({ dark = false }: { dark?: boolean }) {
  const base =
    "group inline-flex items-center gap-2.5 px-5 py-3.5 text-[13px] font-bold uppercase tracking-[0.12em] transition-all duration-300";
  return (
    <div className="flex flex-wrap gap-3">
      <a
        href={SITE.phone}
        className={`${base} ${dark ? "bg-[#07080b] text-[#cffe06]" : "bg-[#cffe06] text-[#07080b]"} hover:-translate-y-1 hover:shadow-[0_14px_40px_-10px_rgba(207,254,6,0.5)]`}
      >
        <Phone size={16} strokeWidth={2.4} /> Позвонить
      </a>
      <a
        href={SITE.wa}
        target="_blank"
        rel="noopener noreferrer"
        className={`${base} border ${dark ? "border-[#07080b]/30 text-[#07080b]" : "border-white/20 text-white"} hover:border-[#1fd655] hover:text-[#1fd655] hover:-translate-y-1`}
      >
        <MessageCircle size={16} strokeWidth={2.4} /> WhatsApp
      </a>
      <a
        href={SITE.tg}
        target="_blank"
        rel="noopener noreferrer"
        className={`${base} border ${dark ? "border-[#07080b]/30 text-[#07080b]" : "border-white/20 text-white"} hover:border-[#36a9e2] hover:text-[#36a9e2] hover:-translate-y-1`}
      >
        <Send size={16} strokeWidth={2.4} /> Telegram
      </a>
      <a
        href={SITE.max}
        target="_blank"
        rel="noopener noreferrer"
        className={`${base} border ${dark ? "border-[#07080b]/30 text-[#07080b]" : "border-white/20 text-white"} hover:border-[#ff3df2] hover:text-[#ff3df2] hover:-translate-y-1`}
      >
        <Hash size={16} strokeWidth={2.4} /> MAX
      </a>
    </div>
  );
}

/* ---------------- Кнопка-стрелка ---------------- */
export function ArrowLink({
  href,
  children,
  className = "",
}: {
  href: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <a
      href={href}
      className={`group inline-flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.14em] ${className}`}
    >
      <span className="u-link">{children}</span>
      <ArrowUpRight
        size={16}
        className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"
      />
    </a>
  );
}
