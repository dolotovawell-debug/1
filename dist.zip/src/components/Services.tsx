import { ArrowUpRight, MonitorPlay } from "lucide-react";
import { SERVICES } from "../lib/site";
import { FlashSection, SectionHead } from "./fx";

export function Services() {
  return (
    <FlashSection id="services" flash="lime" className="plate py-20 md:py-28 px-4 md:px-8">
      <div className="max-w-[1600px] mx-auto">
        <SectionHead
          tag="Что делаем"
          right="08 направлений // полный цикл"
          lines={[
            { t: "Услуги" },
            { t: "под запуск", cls: "t-stroke" },
          ]}
        />

        <div className="grid md:grid-cols-2 xl:grid-cols-4 border-t border-l border-white/10">
          {SERVICES.map((s) => (
            <a
              key={s.id}
              href={s.id === "screen" ? "#screen" : "#contacts"}
              data-flash-inner
              className="group relative border-b border-r border-white/10 p-6 md:p-7 min-h-[320px] flex flex-col justify-between bg-[#07080b] hover:bg-[#cffe06] transition-colors duration-500 overflow-hidden"
            >
              {s.id === "screen" && (
                <span className="absolute top-4 right-4 inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#ff3df2] text-[#07080b] text-[10px] font-bold uppercase tracking-[0.14em]">
                  <MonitorPlay size={12} /> Хит
                </span>
              )}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <span className="text-[11px] tabular tracking-[0.3em] text-[#9ba0a6] group-hover:text-[#07080b]/60 transition-colors duration-500">
                    /{s.n}
                  </span>
                  <ArrowUpRight
                    size={20}
                    className="text-[#cffe06] -rotate-45 group-hover:rotate-0 group-hover:text-[#07080b] transition-all duration-500"
                  />
                </div>
                <h3 className="text-xl md:text-2xl font-bold uppercase tracking-[-0.01em] leading-tight mb-3 group-hover:text-[#07080b] transition-colors duration-500">
                  {s.title}
                </h3>
                <p className="text-[13px] leading-relaxed text-[#9ba0a6] group-hover:text-[#07080b]/75 transition-colors duration-500">
                  {s.desc}
                </p>
              </div>
              <div className="mt-6">
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {s.tags.map((t) => (
                    <span
                      key={t}
                      className="px-2 py-0.5 border border-white/15 text-[10px] uppercase tracking-[0.1em] text-[#c9ccd1] group-hover:border-[#07080b]/30 group-hover:text-[#07080b]/80 transition-colors duration-500"
                    >
                      {t}
                    </span>
                  ))}
                </div>
                <div className="flex items-baseline justify-between border-t border-white/10 group-hover:border-[#07080b]/20 pt-3 transition-colors duration-500">
                  <span className="font-bold text-[15px] group-hover:text-[#07080b] transition-colors duration-500">
                    {s.price}
                  </span>
                  <span className="text-[11px] uppercase tracking-[0.12em] text-[#9ba0a6] group-hover:text-[#07080b]/60 transition-colors duration-500">
                    {s.term}
                  </span>
                </div>
              </div>
            </a>
          ))}
        </div>

        <p data-flash-inner className="mt-6 text-[11px] tracking-[0.25em] uppercase text-[#9ba0a6]">
          * Смета фиксируется в договоре до старта. Цены открытые — без «прайсов по запросу».
        </p>
      </div>
    </FlashSection>
  );
}
