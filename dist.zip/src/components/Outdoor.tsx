import { MonitorPlay, Image as ImageIcon, Clapperboard, Radio, BadgePercent, PackagePlus, MapPin } from "lucide-react";
import { SITE } from "../lib/site";
import { FlashSection, Marquee, TalkButtons } from "./fx";

const FORMATS = [
  {
    icon: Clapperboard,
    t: "Видео",
    d: "Ролики 5–15 секунд в движении. Форматы MP4 / AVI / MOV, разрешение — под пиксель экрана.",
    s: "max внимание",
  },
  {
    icon: ImageIcon,
    t: "Статика",
    d: "Изображения в высоком качестве: JPG / PNG. Минимум текста, крупный шрифт — читается с дороги.",
    s: "чётко и ясно",
  },
  {
    icon: MonitorPlay,
    t: "Анимация",
    d: "GIF или видео с прозрачным фоном. Динамичные элементы, которые цепляют взгляд.",
    s: "эффект живого",
  },
];

const STEPS = [
  { n: "01", t: "Звонок или сообщение", d: "Пишете в мессенджер или звоните — обсуждаем цель и охват." },
  { n: "02", t: "Подбор слотов", d: "Согласуем время и длительность показов под вашу аудиторию." },
  { n: "03", t: "Макет", d: "Помогаем с дизайном ролика или выводим ваш готовый макет." },
  { n: "04", t: "Запуск в эфир", d: "Реклама на экране в согласованные сроки. Фото- и видеоотчёт." },
];

export function Outdoor() {
  return (
    <FlashSection id="screen" flash="mag" className="scanlines">
      {/* фон — живой LED-экран */}
      <div className="absolute inset-0" data-plx="7">
        <img
          src="/images/media-screen.jpg"
          alt="Фасадный медиаэкран СочиПРОФИ в Сочи — ул. Транспортная, 74Б"
          className="kenburns w-full h-[116%] object-cover"
          loading="lazy"
          decoding="async"
        />
      </div>
      <div className="led-vignette absolute inset-0" />
      <div className="absolute inset-0 bg-[#07080b]/45" />

      <div className="relative z-10 px-4 md:px-8 pt-20 md:pt-28 pb-0 max-w-[1600px] mx-auto">
        {/* ON AIR */}
        <div data-flash-inner className="flex flex-wrap items-center gap-4 mb-8">
          <span className="inline-flex items-center gap-2.5 px-4 py-2 bg-[#ff3df2] text-[#07080b] text-[12px] font-bold uppercase tracking-[0.2em]">
            <span className="pulse-dot w-2 h-2 rounded-full bg-[#07080b]" />
            ON AIR · 24/7
          </span>
          <span className="inline-flex items-center gap-2 text-[11px] md:text-[12px] tracking-[0.25em] uppercase text-white/85">
            <MapPin size={13} className="text-[#ff3df2]" />
            Собственный фасадный экран — {SITE.address}
          </span>
        </div>

        {/* Гигантский заголовок с глитчем */}
        <div data-flash-inner>
          <h2 data-vely className="font-bold uppercase leading-[0.88] tracking-[-0.035em] text-[clamp(2.9rem,9.5vw,9.5rem)]">
            <span className="block t-stroke">Режь взгляд</span>
            <span
              className="glitch on block text-[#cffe06] drop-shadow-[0_0_35px_rgba(207,254,6,0.35)]"
              data-text="Медиаэкран"
            >
              Медиаэкран
            </span>
            <span className="block">
              Наружная реклама<span className="text-[#ff3df2]">.</span>
            </span>
          </h2>
          <p className="aeo-answer mt-6 max-w-2xl text-[15px] md:text-lg leading-relaxed text-white/85">
            Ваша реклама на <b className="text-[#cffe06]">собственном LED-экране</b> в Сочи —
            ул. Транспортная, 74Б: плотный трафик мимо экрана каждый день. Видео, статика и
            анимация — заметный офлайн-формат для бренда, акций и событий.{" "}
            <b>От 15 000 ₽ в неделю.</b>
          </p>
        </div>

        {/* Форматы */}
        <div className="mt-12 grid md:grid-cols-3 gap-4">
          {FORMATS.map((f) => (
            <div
              key={f.t}
              data-flash-inner
              className="lift group border border-white/25 bg-[#07080b]/65 backdrop-blur-md p-6 md:p-7 hover:border-[#cffe06]"
            >
              <div className="flex items-center justify-between mb-5">
                <f.icon size={26} className="text-[#cffe06]" />
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#ff3df2]">
                  {f.s}
                </span>
              </div>
              <h3 className="text-2xl font-bold uppercase mb-2">{f.t}</h3>
              <p className="text-[13px] leading-relaxed text-white/70">{f.d}</p>
            </div>
          ))}
        </div>

        {/* Цена + шаги */}
        <div className="mt-4 grid lg:grid-cols-[1fr_1.35fr] gap-4">
          <div
            data-flash-inner
            className="bg-[#cffe06] text-[#07080b] p-6 md:p-8 flex flex-col justify-between min-h-[300px]"
          >
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-bold uppercase tracking-[0.25em]">Размещение</p>
              <Radio size={20} />
            </div>
            <div>
              <p className="text-[13px] uppercase tracking-[0.15em] font-bold">от</p>
              <p className="text-[clamp(2.6rem,4.5vw,4.2rem)] font-bold tracking-[-0.03em] leading-none tabular">
                15 000 ₽
              </p>
              <p className="text-[13px] font-bold uppercase tracking-[0.15em] mt-1">
                / неделя показов
              </p>
            </div>
            <ul className="space-y-2 text-[13px] font-medium">
              <li className="flex items-center gap-2">
                <BadgePercent size={15} /> Скидки при размещении от 1 месяца
              </li>
              <li className="flex items-center gap-2">
                <PackagePlus size={15} /> Комбо-пакеты: экран + сайт + SEO + директ
              </li>
            </ul>
          </div>

          <div data-flash-inner className="border border-white/20 bg-[#07080b]/70 backdrop-blur-md p-6 md:p-8">
            <p className="text-[11px] uppercase tracking-[0.3em] text-white/70 mb-6">
              Как попасть на экран
            </p>
            <ol className="grid sm:grid-cols-2 gap-x-8 gap-y-6">
              {STEPS.map((st) => (
                <li key={st.n} className="flex gap-4">
                  <span className="text-[#ff3df2] font-bold tabular text-sm pt-0.5">
                    {st.n}
                  </span>
                  <div>
                    <p className="font-bold uppercase text-[14px] tracking-[0.04em] mb-1">
                      {st.t}
                    </p>
                    <p className="text-[13px] text-white/65 leading-relaxed">{st.d}</p>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mt-8">
              <TalkButtons dark />
            </div>
          </div>
        </div>
      </div>

      {/* лайм-лента снизу секции */}
      <div className="relative z-10 mt-12 bg-[#cffe06]" data-flash-inner>
        <Marquee
          items={[
            "Ваша реклама видна с дороги",
            "ул. Транспортная, 74Б",
            "видео 5–15 сек",
            "запуск за 3–5 дней",
            "экран работает 24/7",
          ]}
          dur="22s"
          className="py-3 text-[#07080b] text-[13px] md:text-sm font-bold uppercase tracking-[0.18em]"
          sepCls="text-[#07080b]/50"
        />
      </div>
    </FlashSection>
  );
}
